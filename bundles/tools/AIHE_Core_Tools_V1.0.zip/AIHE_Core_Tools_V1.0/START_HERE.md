﻿# Artificial Intelligence and Healthcare Economics — Core Tools V1.0

**Release:** V1.0  
**Release date:** 2026-09-02  
**Book alignment:** revised 412-page edition; 15 chapters; 31 principal figures; 46 principal tables

Begin with the consolidated Word form in `forms/`, the consolidated Excel wb in `workbooks/`, or the current catalogues in `catalogs/`. Individual records and workbooks are provided for selective institutional use. Worked examples and demonstration data are synthetic unless a documented source states otherwise.

Use stable resource, chapter, section, figure, table, and case identifiers rather than printed page numbers. Adapt every resource to the applicable jurisdiction, organization, population, workflow, system version, evidence base, contract, and accountable decision process before institutional use.
