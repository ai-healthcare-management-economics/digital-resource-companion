﻿# AIHE Core Tools V1.0

This essentials pack is synchronized with the revised textbook: 15 chapters, 31 principal figures, and 46 principal tables. It contains the 24 core institutional records in Word and Excel, current catalogues, the revised Chapter 15 worked example, supplementary cases, selected computational resources, and migration crosswalks.

All examples and demonstration data are synthetic unless a documented source states otherwise. Replace them with authorized local evidence before institutional use. A completed resource or model output does not constitute authorization.
