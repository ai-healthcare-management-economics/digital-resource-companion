# Package Contents

## Forms

- `AIHE_Core_Resource_Forms_V1.0.docx` — editable collection of the 19 core institutional records
- `AIHE_Core_Resource_Forms_V1.0.pdf` — stable printable version

## Workbooks

- `AIHE_Core_Resource_Workbooks_V1.0.xlsx` — consolidated workbook containing the 19 core institutional records
- `WORKBOOK_GUIDE.md` — completion, formula-control, data-protection, and finalization guidance

## Governance documents

- `README.md`
- `LICENSE.md`
- `LIMITED_USE_AND_DISCLAIMER.md`
- `VERSION.txt`
- `MANIFEST.txt`
- `CHECKSUMS_SHA256.txt`
