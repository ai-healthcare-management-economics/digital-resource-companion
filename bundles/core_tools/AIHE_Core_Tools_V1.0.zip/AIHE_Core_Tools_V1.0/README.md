# AIHE Core Tools Pack V1.0

The **Core Tools Pack** is the lightweight essentials package for *Artificial Intelligence in Healthcare Management and Economics: Evidence, Value, Governance, and Lifecycle Decision-Making*.

It is intended for users who principally need the 19 core institutional records in consolidated document and workbook form without the complete worked-example, analytical, website, and canonical source collections.

## Included

| Folder | Contents |
|---|---|
| `Forms/` | Consolidated editable Word forms and printable PDF |
| `Workbooks/` | Consolidated Excel workbook and workbook guidance |
| Root documents | Licence, limited-use notice, version information, package description, manifest, and checksums |

The forms support structured deliberation, accountable decisions, conditions, responsibilities, review dates, and lifecycle records. The workbook supports structured inputs, comparisons, calculations, monitoring, and repeated review.

The pack is a **convenience subset**, not a separate companion edition. The Reader and Practitioner Edition provides the broader practical collection, while the Canonical Source contains the complete authoritative materials.

All worked content and numerical illustrations are synthetic unless explicitly stated otherwise. Institutional users must replace illustrative material with authorized evidence and adapt the records to the applicable jurisdiction, organization, population, workflow, technical environment, and decision authority.
